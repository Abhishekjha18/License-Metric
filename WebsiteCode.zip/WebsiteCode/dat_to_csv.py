import streamlit as st
import pandas as pd
import numpy as np
import struct
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.figure_factory as ff
from io import BytesIO
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc,
    mean_squared_error,
    r2_score
)
import joblib  # For loading custom models
import pickle  # For serializing the pipeline for download
import warnings

warnings.filterwarnings('ignore')

###############################################
# Helper Functions for CSV Data Processing
###############################################
@st.cache_data
def load_data(file):
    """
    Load CSV data, convert dtypes, and attempt to fix columns for Arrow compatibility.
    """
    try:
        df = pd.read_csv(file)
        df = df.convert_dtypes()
        # Attempt to convert object columns to numeric if possible.
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = pd.to_numeric(df[col], errors='ignore')
        print("Data loaded successfully with shape:", df.shape)
        return df
    except Exception as e:
        st.error(f"Error loading data: {e}")
        return pd.DataFrame()

def get_feature_types(df, target_col):
    """
    Separates features into numeric and categorical lists.
    """
    X = df.drop(columns=[target_col])
    numeric_cols = X.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = X.select_dtypes(include=['object', 'string']).columns.tolist()
    print("Numeric columns:", numeric_cols)
    print("Categorical columns:", categorical_cols)
    return numeric_cols, categorical_cols

def create_preprocessing_pipeline(numeric_cols, categorical_cols):
    """
    Create a ColumnTransformer that scales numeric features and one-hot encodes categoricals.
    """
    transformers = []
    if numeric_cols:
        transformers.append(('num', StandardScaler(), numeric_cols))
    if categorical_cols:
        transformers.append(('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols))
    preprocessor = ColumnTransformer(transformers=transformers)
    print("Preprocessing pipeline created with transformers:", transformers)
    return preprocessor

def preprocess_target(y):
    """
    Encode target variable if it's categorical.
    """
    if y.dtype == 'object' or y.dtype.name == 'category':
        le = LabelEncoder()
        y_encoded = le.fit_transform(y)
        print("Target variable encoded. Classes:", le.classes_)
        return y_encoded, le
    else:
        print("Target variable is numeric. No encoding applied.")
        return y, None

def plot_confusion_matrix(cm, class_names):
    """
    Plot confusion matrix using seaborn heatmap.
    """
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    return fig

def plot_roc_curve(y_test, y_proba, pos_label=1):
    """
    Plot ROC curve and calculate AUC.
    """
    fpr, tpr, thresholds = roc_curve(y_test, y_proba[:, 1], pos_label=pos_label)
    roc_auc = auc(fpr, tpr)
    fig = px.area(
        x=fpr, y=tpr, 
        title=f'ROC Curve (AUC = {roc_auc:.4f})',
        labels={'x': 'False Positive Rate', 'y': 'True Positive Rate'},
        width=600, height=400
    )
    fig.add_scatter(x=fpr, y=tpr, mode='lines')
    fig.add_scatter(x=[0, 1], y=[0, 1], mode='lines', line=dict(dash='dash'))
    return fig

def plot_residuals(y_test, y_pred):
    """
    Create a residual plot for regression.
    """
    residuals = y_test - y_pred
    fig = px.scatter(
        x=y_pred, y=residuals, 
        labels={'x':'Predicted', 'y':'Residuals'}, 
        title="Residual Plot"
    )
    fig.add_shape(
        type="line", x0=y_pred.min(), x1=y_pred.max(), 
        y0=0, y1=0, line=dict(color="red", dash="dash")
    )
    return fig

###############################################
# Sensor Data Processing Functions
###############################################
def parse_lsm6dsv16x(file_obj, data_type):
    """
    Parses LSM6DSV16X sensor data from a binary file (file-like object).
    Assumes each sample is 6 bytes (3 channels x int16).
    Returns a numpy array of shape (num_samples, 3).
    """
    import struct
    try:
        data = file_obj.read()
        num_samples = len(data) // 6  # 6 bytes per sample
        parsed_data = [struct.unpack('hhh', data[i*6:(i+1)*6]) for i in range(num_samples)]
        print(f"Parsed {num_samples} samples from {data_type} data.")
        return np.array(parsed_data)
    except Exception as e:
        st.error(f"Error parsing {data_type} data: {e}")
        return np.array([])

def kalman_filter(data, process_variance=1e-5, measurement_variance=1e-2):
    """
    A simple Kalman filter for 1D data.
    data: numpy array (1D)
    Returns filtered data as numpy array.
    """
    n = len(data)
    filtered = np.zeros(n)
    posteri_estimate = data[0]
    posteri_error_estimate = 1.0
    for i in range(n):
        priori_estimate = posteri_estimate
        priori_error_estimate = posteri_error_estimate + process_variance
        kalman_gain = priori_error_estimate / (priori_error_estimate + measurement_variance)
        posteri_estimate = priori_estimate + kalman_gain * (data[i] - priori_estimate)
        posteri_error_estimate = (1 - kalman_gain) * priori_error_estimate
        filtered[i] = posteri_estimate
    return filtered

###############################################
# Main App Layout
###############################################
st.set_page_config(page_title="ML Dashboard", layout="wide")
st.title("Machine Learning Dashboard for Driving Data")
print("Streamlit app started.")

# -- Re-ordered tab names so "Sensor Data Processing" is second --
tab_names = [
    "Overview",
    "Sensor Data Processing",
    "Visualizations",
    "Modeling",
    "Evaluation",
    "Custom Model",
    "Predictions",
]
tabs = st.tabs(tab_names)
(
    tab_overview,
    tab_sensor,
    tab_viz,
    tab_model,
    tab_eval,
    tab_custom,
    tab_predict
) = tabs
print("Main tabs created (Sensor Data Processing is second).")

##########################
# 1) CSV Data Processing Flow
##########################
st.sidebar.header("CSV Data Configuration")
uploaded_file = st.sidebar.file_uploader("Upload CSV File", type=["csv"])

# We keep references to a pipeline in session_state
csv_pipeline_key = "trained_pipeline_csv"

if uploaded_file is not None:
    df = load_data(uploaded_file)
    if df.empty:
        st.error("The uploaded CSV file is empty or invalid.")
        print("Empty DataFrame loaded from CSV.")
    else:
        st.subheader("Data Preview (first 10 rows)")
        st.dataframe(df.head(10))
        print("CSV data preview displayed.")
        
        # Target column selection
        target_options = df.columns.tolist()
        default_target = "Behavior" if "Behavior" in target_options else target_options[-1]
        target_col = st.sidebar.selectbox(
            "Select Target Column",
            options=target_options,
            index=target_options.index(default_target)
        )
        print("Target column selected:", target_col)
        
        # Infer task type
        y = df[target_col]
        if y.dtype in ['object', 'string'] or len(np.unique(y)) < 20:
            inferred_task = "Classification"
        else:
            inferred_task = "Regression"
        task_type = st.sidebar.radio(
            "Task Type",
            ["Classification", "Regression"],
            index=0 if inferred_task=="Classification" else 1
        )
        print("Task type inferred and selected:", task_type)
        
        # Model selection and hyperparameters
        model_choice = st.sidebar.selectbox("Select Model", ["Random Forest", "XGBoost (if installed)"])
        print("Model selected:", model_choice)
        st.sidebar.subheader("Hyperparameters")
        n_estimators = st.sidebar.slider("n_estimators", 10, 500, 100, step=10)
        max_depth = st.sidebar.slider("max_depth", 1, 50, 5, step=1)
        params = {"n_estimators": n_estimators, "max_depth": max_depth}
        print("Hyperparameters set:", params)
        
        # Build pipeline for CSV data
        numeric_cols, categorical_cols = get_feature_types(df, target_col)
        preprocessor = create_preprocessing_pipeline(numeric_cols, categorical_cols)
        y_processed, target_encoder = preprocess_target(y)
        X = df.drop(columns=[target_col])
        X_train, X_test, y_train, y_test = train_test_split(X, y_processed, test_size=0.2, random_state=42)
        print("CSV data split into training and testing sets.")
        
        # Initialize model
        model = None
        if task_type == "Classification":
            if model_choice == "Random Forest":
                model = RandomForestClassifier(**params, random_state=42)
            elif model_choice.startswith("XGBoost"):
                try:
                    from xgboost import XGBClassifier
                    model = XGBClassifier(**params, use_label_encoder=False, eval_metric='mlogloss', random_state=42)
                except ImportError:
                    st.error("XGBoost is not installed. Please install it or select another model.")
        else:
            if model_choice == "Random Forest":
                model = RandomForestRegressor(**params, random_state=42)
            elif model_choice.startswith("XGBoost"):
                try:
                    from xgboost import XGBRegressor
                    model = XGBRegressor(**params, random_state=42)
                except ImportError:
                    st.error("XGBoost is not installed. Please install it or select another model.")
        if model is None:
            st.error("Model initialization failed.")
            print("Model initialization failed for CSV data.")
        else:
            print("Model initialized for CSV data:", model)
        
        # -- Tab: Overview
        with tab_overview:
            print("CSV Overview tab reached.")
            st.header("Dataset Overview")
            st.markdown("### Data Summary")
            st.dataframe(df.describe(include='all').T)
            st.markdown("### Column-by-Column Overview")
            overview_data = {
                "Column": df.columns,
                "Data Type": [str(df[col].dtype) for col in df.columns],
                "Missing Values": [df[col].isnull().sum() for col in df.columns],
                "Unique Values": [df[col].nunique() for col in df.columns],
                "Sample Values": [
                    ', '.join(map(str, list(df[col].dropna().unique()[:3]))) for col in df.columns
                ],
            }
            overview_df = pd.DataFrame(overview_data)
            st.dataframe(overview_df)
            print("CSV Overview data displayed.")
        
        # -- Tab: Visualizations
        with tab_viz:
            print("CSV Visualizations tab reached.")
            st.header("Data Visualizations")
            st.subheader("Distribution Plot")
            col_to_plot = st.selectbox("Select Column for Distribution", df.columns.tolist())
            try:
                fig_dist = px.histogram(df, x=col_to_plot, title=f"Distribution of {col_to_plot}")
                st.plotly_chart(fig_dist, use_container_width=True)
                print(f"Distribution plot for {col_to_plot} displayed.")
            except Exception as e:
                st.error(f"Error in distribution plot: {e}")
            if numeric_cols:
                st.subheader("Correlation Heatmap (Numeric Features)")
                corr = df[numeric_cols].corr()
                fig, ax = plt.subplots(figsize=(10, 8))
                sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
                st.pyplot(fig)
                print("Correlation heatmap displayed.")
            else:
                st.write("No numeric columns available for correlation heatmap.")
            if st.checkbox("Show Pair Plot for Numeric Features", value=False):
                try:
                    fig_pair = ff.create_scatterplotmatrix(
                        df[numeric_cols], diag='histogram', index=0, height=800, width=800
                    )
                    st.plotly_chart(fig_pair)
                    print("Pair plot displayed.")
                except Exception as e:
                    st.error(f"Error creating pair plot: {e}")
        
        # -- Tab: Modeling
        with tab_model:
            print("CSV Modeling tab reached.")
            st.header("Model Training")
            if model is None:
                st.error("Model initialization failed. Check settings or install XGBoost.")
            else:
                st.write("Training the model using an ML pipeline with preprocessing...")
                pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('model', model)])
                pipeline.fit(X_train, y_train)
                st.success("Model training complete!")
                st.session_state[csv_pipeline_key] = pipeline
                print("Model training completed and pipeline stored in session_state for CSV data.")
        
        # -- Tab: Evaluation
        with tab_eval:
            print("CSV Evaluation tab reached.")
            st.header("Model Evaluation")
            if csv_pipeline_key not in st.session_state:
                st.error("Please train a model in the 'Modeling' tab first.")
            else:
                pipeline = st.session_state[csv_pipeline_key]
                y_pred = pipeline.predict(X_test)
                if task_type == "Classification":
                    acc = accuracy_score(y_test, y_pred)
                    st.write(f"**Accuracy:** {acc:.4f}")
                    cm = confusion_matrix(y_test, y_pred)
                    class_names = target_encoder.classes_ if target_encoder is not None else np.unique(y_test)
                    st.write("### Confusion Matrix")
                    fig_cm = plot_confusion_matrix(cm, class_names)
                    st.pyplot(fig_cm)
                    st.write("### Classification Report")
                    report = classification_report(y_test, y_pred, output_dict=True)
                    st.dataframe(pd.DataFrame(report).transpose())
                    if len(np.unique(y_test)) == 2:
                        try:
                            y_proba = pipeline.predict_proba(X_test)
                            fig_roc = plot_roc_curve(y_test, y_proba, pos_label=1)
                            st.plotly_chart(fig_roc)
                            print("ROC curve displayed.")
                        except Exception as e:
                            st.error(f"Error generating ROC curve: {e}")
                else:
                    mse = mean_squared_error(y_test, y_pred)
                    r2 = r2_score(y_test, y_pred)
                    st.write(f"**Mean Squared Error:** {mse:.4f}")
                    st.write(f"**R² Score:** {r2:.4f}")
                    st.write("### Residual Plot")
                    fig_res = plot_residuals(y_test, y_pred)
                    st.plotly_chart(fig_res)
                print("CSV Evaluation metrics displayed.")
        
        # -- Tab: Custom Model
        with tab_custom:
            print("CSV Custom Model tab reached.")
            st.header("Custom Model Integration")
            custom_model_file = st.file_uploader("Upload a custom model (Pickle file)", type=["pkl"], key="custom_model_csv")
            if custom_model_file is not None:
                try:
                    custom_model = joblib.load(custom_model_file)
                    st.success("Custom model loaded successfully!")
                    print("Custom model loaded from CSV flow.")
                    if st.button("Evaluate Custom Model"):
                        y_pred_custom = custom_model.predict(X_test)
                        if task_type == "Classification":
                            acc_custom = accuracy_score(y_test, y_pred_custom)
                            st.write(f"**Custom Model Accuracy:** {acc_custom:.4f}")
                            cm_custom = confusion_matrix(y_test, y_pred_custom)
                            class_names = (
                                target_encoder.classes_ if target_encoder is not None else np.unique(y_test)
                            )
                            fig_cm_custom = plot_confusion_matrix(cm_custom, class_names)
                            st.pyplot(fig_cm_custom)
                            report_custom = classification_report(y_test, y_pred_custom, output_dict=True)
                            st.dataframe(pd.DataFrame(report_custom).transpose())
                        else:
                            mse_custom = mean_squared_error(y_test, y_pred_custom)
                            r2_custom = r2_score(y_test, y_pred_custom)
                            st.write(f"**Custom Model MSE:** {mse_custom:.4f}")
                            st.write(f"**Custom Model R²:** {r2_custom:.4f}")
                        print("Custom model evaluation completed for CSV data.")
                except Exception as e:
                    st.error(f"Error loading custom model: {e}")
                    print("Error loading custom model:", e)
        
        # -- Tab: Predictions
        with tab_predict:
            print("CSV Predictions tab reached.")
            st.header("Make Predictions")
            st.write("Enter values for each feature:")
            input_data = {}
            for col in X.columns:
                if col in numeric_cols:
                    default_val = float(X[col].mean())
                    input_data[col] = st.number_input(f"{col}", value=default_val)
                else:
                    unique_vals = df[col].dropna().unique().tolist()
                    if len(unique_vals) == 0:
                        unique_vals = [""]
                    input_data[col] = st.selectbox(f"{col}", unique_vals)
            input_df = pd.DataFrame([input_data])
            if st.button("Predict"):
                if csv_pipeline_key not in st.session_state:
                    st.error("No trained model available. Please train a model in the 'Modeling' tab.")
                    print("Prediction attempted without a trained model for CSV data.")
                else:
                    pipeline = st.session_state[csv_pipeline_key]
                    try:
                        prediction = pipeline.predict(input_df)
                        if task_type == "Classification" and target_encoder is not None:
                            prediction = target_encoder.inverse_transform(prediction)
                        st.write("### Prediction:")
                        st.write(prediction)
                        print("CSV Prediction made:", prediction)
                    except Exception as e:
                        st.error(f"Prediction failed: {e}")
                        print("Error during CSV prediction:", e)
        
        # -- Download trained model (CSV data)
        st.sidebar.header("Download Trained Model (CSV Data)")
        if csv_pipeline_key in st.session_state:
            try:
                model_bytes = pickle.dumps(st.session_state[csv_pipeline_key])
                st.sidebar.download_button(
                    "Download Model", data=model_bytes, file_name="trained_pipeline_csv.pkl"
                )
                print("Model download button created for CSV data.")
            except Exception as e:
                st.sidebar.error(f"Error during model download: {e}")
                print("Error during model download for CSV data:", e)

else:
    st.write("Upload a CSV file in the **sidebar** to begin.")
    print("No CSV file uploaded yet.")


#############################
# 2) Sensor Data Processing Tab
#############################
with tab_sensor:
    print("Sensor Data Processing tab reached.")
    st.header("Sensor Data Processing")
    st.write("**Upload raw sensor data files** to process into a combined CSV format with Kalman filtering and orientation.")

    # Two file uploaders for .dat files
    col1, col2 = st.columns(2)
    with col1:
        accel_file = st.file_uploader("Upload Accelerometer File (.dat)", type=["dat"], key="accel_file")
    with col2:
        gyro_file = st.file_uploader("Upload Gyroscope File (.dat)", type=["dat"], key="gyro_file")
    
    st.markdown("### Sensor Data Parameters")
    sampling_rate = st.number_input("Sampling Rate (Hz)", value=100.0, step=1.0)
    start_timestamp = st.number_input("Starting Timestamp (s)", value=0.0, step=0.1)
    system_activated = st.text_input("System Activated", value="1")
    trip_date = st.text_input("Trip Date", value="20151110175712")
    distance = st.text_input("Distance", value="16km")
    driver = st.text_input("Driver", value="D1")
    behavior = st.text_input("Behavior", value="NORMAL")
    road = st.text_input("Road", value="SECONDARY")
    apply_kf = st.checkbox("Apply Kalman Filter to Accelerometer Data", value=True)
    
    # A separate key to store sensor-based pipeline if you want to train models from sensor data
    sensor_pipeline_key = "trained_pipeline_sensor"

    # If both files are uploaded, parse and process
    if accel_file is not None and gyro_file is not None:
        accel_data = parse_lsm6dsv16x(accel_file, "accelerometer")
        gyro_data = parse_lsm6dsv16x(gyro_file, "gyroscope")
        
        if accel_data.size == 0 or gyro_data.size == 0:
            st.error("Error parsing sensor data files. Check logs for details.")
            print("Error parsing sensor files.")
        else:
            num_samples = min(len(accel_data), len(gyro_data))
            accel_data = accel_data[:num_samples]
            gyro_data = gyro_data[:num_samples]
            print(f"Using {num_samples} samples from sensor data.")
            
            # Generate timestamps
            timestamps = start_timestamp + np.arange(num_samples) * (1.0 / sampling_rate)
            
            # Apply Kalman Filter if selected
            if apply_kf:
                accel_kf = np.zeros_like(accel_data, dtype=float)
                for i in range(3):
                    accel_kf[:, i] = kalman_filter(accel_data[:, i])
                print("Kalman filtering applied to accelerometer data.")
            else:
                accel_kf = np.full_like(accel_data, np.nan)
                print("Kalman filtering not applied.")
            
            # Compute orientation from filtered accelerometer + integrated gyro
            use_data = accel_kf if apply_kf else accel_data
            # Simple roll, pitch from accelerometer
            roll = np.degrees(np.arctan2(use_data[:, 1], use_data[:, 2]))
            pitch = np.degrees(
                np.arctan2(-use_data[:, 0], np.sqrt(use_data[:, 1]**2 + use_data[:, 2]**2))
            )
            # Integrate gyro Z axis for yaw
            dt = 1.0 / sampling_rate
            yaw = np.cumsum(gyro_data[:num_samples, 2]) * dt
            
            # Build final dataframe
            sensor_df = pd.DataFrame({
                "Timestamp_s": timestamps,
                "SystemActivated": system_activated,
                "AccelX_Gs": accel_data[:, 0],
                "AccelY_Gs": accel_data[:, 1],
                "AccelZ_Gs": accel_data[:, 2],
                "AccelX_KF_Gs": accel_kf[:, 0] if apply_kf else np.nan,
                "AccelY_KF_Gs": accel_kf[:, 1] if apply_kf else np.nan,
                "AccelZ_KF_Gs": accel_kf[:, 2] if apply_kf else np.nan,
                "Roll_deg": roll,
                "Pitch_deg": pitch,
                "Yaw_deg": yaw,
                "TripDate": trip_date,
                "Distance": distance,
                "Driver": driver,
                "Behavior": behavior,
                "Road": road
            })
            st.subheader("Processed Sensor Data")
            st.dataframe(sensor_df.head(10))
            print("Processed sensor data displayed.")
            
            # Download processed sensor CSV
            csv_bytes = sensor_df.to_csv(index=False).encode('utf-8')
            st.download_button(
                "Download Processed Sensor CSV",
                data=csv_bytes,
                file_name="processed_sensor_data.csv"
            )
            print("Sensor data download button created.")
            
            # Simple Model Comparison on RAW vs. IMPROVED data
            st.markdown("### Model Comparison on Sensor Data")
            st.write("Train a simple RandomForest on **RAW** vs. **IMPROVED** sensor features for demonstration.")

            # Create a dummy target from 'Behavior' (0 if NORMAL, else 1) for demonstration
            sensor_df["Target"] = sensor_df["Behavior"].apply(lambda x: 0 if str(x).upper()=="NORMAL" else 1)
            
            # RAW features: accelerometer only
            raw_features = sensor_df[["AccelX_Gs", "AccelY_Gs", "AccelZ_Gs"]]
            # IMPROVED features: Kalman + orientation
            # (If user didn't apply KF, these columns might be NaN, but we still show the logic)
            improved_features = sensor_df[[
                "AccelX_KF_Gs", "AccelY_KF_Gs", "AccelZ_KF_Gs",
                "Roll_deg", "Pitch_deg", "Yaw_deg"
            ]]

            if st.button("Train Model on RAW Sensor Data"):
                X_raw = raw_features
                y_raw = sensor_df["Target"]
                X_train_raw, X_test_raw, y_train_raw, y_test_raw = train_test_split(
                    X_raw, y_raw, test_size=0.2, random_state=42
                )
                model_raw = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
                model_raw.fit(X_train_raw, y_train_raw)
                y_pred_raw = model_raw.predict(X_test_raw)
                acc_raw = accuracy_score(y_test_raw, y_pred_raw)
                st.write(f"**RAW Sensor Data Model Accuracy:** {acc_raw:.4f}")
                print("Model trained on RAW sensor data. Accuracy:", acc_raw)
            
            if st.button("Train Model on IMPROVED Sensor Data"):
                X_imp = improved_features
                y_imp = sensor_df["Target"]
                X_train_imp, X_test_imp, y_train_imp, y_test_imp = train_test_split(
                    X_imp, y_imp, test_size=0.2, random_state=42
                )
                model_imp = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
                model_imp.fit(X_train_imp, y_train_imp)
                y_pred_imp = model_imp.predict(X_test_imp)
                acc_imp = accuracy_score(y_test_imp, y_pred_imp)
                st.write(f"**IMPROVED Sensor Data Model Accuracy:** {acc_imp:.4f}")
                print("Model trained on IMPROVED sensor data. Accuracy:", acc_imp)
    else:
        st.info("Please upload both accelerometer and gyroscope .dat files above.")
        print("Sensor data files not uploaded yet.")
