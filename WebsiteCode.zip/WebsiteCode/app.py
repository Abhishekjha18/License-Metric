import streamlit as st
import pandas as pd
import numpy as np
import struct
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.figure_factory as ff
from io import BytesIO
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder, LabelEncoder
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc,
    mean_squared_error,
    r2_score
)
import joblib  # For loading custom models
import pickle  # For serializing models
import warnings

warnings.filterwarnings('ignore')

###############################################
# Helper Functions for CSV Data Processing
###############################################
@st.cache_data
def load_data(file):
    """
    Load CSV data, convert dtypes, and fix columns for Arrow compatibility.
    """
    try:
        df = pd.read_csv(file)
        df = df.convert_dtypes()
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = pd.to_numeric(df[col], errors='ignore')
        print("CSV loaded, shape:", df.shape)
        return df
    except Exception as e:
        st.error(f"Error loading CSV: {e}")
        return pd.DataFrame()

def get_feature_types(df, target_col):
    """
    Separate features into numeric and categorical lists.
    """
    X = df.drop(columns=[target_col])
    numeric_cols = X.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = X.select_dtypes(include=['object', 'string']).columns.tolist()
    print("Numeric cols:", numeric_cols)
    print("Categorical cols:", categorical_cols)
    return numeric_cols, categorical_cols

def create_preprocessing_pipeline(numeric_cols, categorical_cols):
    """
    Build a ColumnTransformer that scales numeric features and one-hot encodes categoricals.
    """
    transformers = []
    if numeric_cols:
        transformers.append(('num', StandardScaler(), numeric_cols))
    if categorical_cols:
        transformers.append(('cat', OneHotEncoder(handle_unknown='ignore'), categorical_cols))
    preprocessor = ColumnTransformer(transformers=transformers)
    print("Preprocessing pipeline created:", transformers)
    return preprocessor

def preprocess_target(y):
    """
    Encode target variable if it's categorical.
    """
    if y.dtype == 'object' or y.dtype.name == 'category':
        le = LabelEncoder()
        y_encoded = le.fit_transform(y)
        print("Target encoded. Classes:", le.classes_)
        return y_encoded, le
    else:
        print("Target is numeric.")
        return y, None

###############################################
# Plotting Helpers
###############################################
def plot_confusion_matrix(cm, class_names):
    """
    Plot confusion matrix using seaborn heatmap.
    """
    fig, ax = plt.subplots()
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=class_names, yticklabels=class_names, ax=ax)
    ax.set_xlabel('Predicted')
    ax.set_ylabel('True')
    return fig

def plot_roc_curve(y_test, y_proba, pos_label=1):
    """
    Plot ROC curve and calculate AUC.
    """
    fpr, tpr, _ = roc_curve(y_test, y_proba[:, 1], pos_label=pos_label)
    roc_auc = auc(fpr, tpr)
    fig = px.area(
        x=fpr, y=tpr,
        title=f'ROC Curve (AUC = {roc_auc:.4f})',
        labels={'x': 'False Positive Rate', 'y': 'True Positive Rate'},
        width=600, height=400
    )
    fig.add_scatter(x=fpr, y=tpr, mode='lines')
    fig.add_scatter(x=[0,1], y=[0,1], mode='lines', line=dict(dash='dash'))
    return fig

def plot_residuals(y_test, y_pred):
    """
    Create a residual plot for regression.
    """
    residuals = y_test - y_pred
    fig = px.scatter(
        x=y_pred, y=residuals,
        labels={'x': 'Predicted', 'y': 'Residuals'},
        title="Residual Plot"
    )
    fig.add_shape(
        type="line", x0=y_pred.min(), x1=y_pred.max(),
        y0=0, y1=0, line=dict(color="red", dash="dash")
    )
    return fig

###############################################
# Sensor Data Processing Functions
###############################################
def parse_lsm6dsv16x(file_obj, data_type):
    """
    Parses LSM6DSV16X sensor data from a binary file.
    Assumes each sample is 6 bytes (3 channels x int16).
    Returns np.array of shape (num_samples, 3).
    """
    try:
        data = file_obj.read()
        num_samples = len(data) // 6
        parsed_data = [struct.unpack('hhh', data[i*6:(i+1)*6]) for i in range(num_samples)]
        print(f"Parsed {num_samples} samples from {data_type}.")
        return np.array(parsed_data)
    except Exception as e:
        st.error(f"Error parsing {data_type}: {e}")
        return np.array([])

def kalman_filter(data, process_variance=1e-5, measurement_variance=1e-2):
    """
    A simple Kalman filter for 1D data.
    Returns filtered data as np.array.
    """
    n = len(data)
    filtered = np.zeros(n)
    posteri_estimate = data[0]
    posteri_error_estimate = 1.0
    for i in range(n):
        priori_estimate = posteri_estimate
        priori_error_estimate = posteri_error_estimate + process_variance
        kalman_gain = priori_error_estimate / (priori_error_estimate + measurement_variance)
        posteri_estimate = priori_estimate + kalman_gain * (data[i] - priori_estimate)
        posteri_error_estimate = (1 - kalman_gain) * priori_error_estimate
        filtered[i] = posteri_estimate
    return filtered

###############################################
# MAIN APP LAYOUT
###############################################
st.set_page_config(page_title="ML Dashboard", layout="wide")
st.title("Machine Learning Dashboard for Driving Data")
print("Streamlit app started.")

# Define tabs – 7 tabs
tab_names = ["Overview", "Sensor Data Processing", "Visualizations", "Modeling", "Evaluation", "Custom Model", "Predictions"]
tabs = st.tabs(tab_names)
(tab_overview, tab_sensor, tab_viz, tab_model, tab_eval, tab_custom, tab_predict) = tabs
print("Main tabs created:", tab_names)

###############################################
# CSV DATA PROCESSING SECTION (Sidebar & Tabs)
###############################################
st.sidebar.header("CSV Data Configuration")
uploaded_file = st.sidebar.file_uploader("Upload CSV File", type=["csv"])
csv_pipeline_key = "trained_pipeline_csv"

if uploaded_file is not None:
    df = load_data(uploaded_file)
    if df.empty:
        st.error("The uploaded CSV file is empty or invalid.")
        print("Empty CSV DataFrame.")
    else:
        st.subheader("Data Preview (first 10 rows)")
        st.dataframe(df.head(10))
        print("CSV preview displayed.")
        
        target_options = df.columns.tolist()
        default_target = "Behavior" if "Behavior" in target_options else target_options[-1]
        target_col = st.sidebar.selectbox("Select Target Column", options=target_options, index=target_options.index(default_target))
        print("CSV Target column:", target_col)
        
        y = df[target_col]
        if y.dtype in ['object', 'string'] or len(np.unique(y)) < 20:
            inferred_task = "Classification"
        else:
            inferred_task = "Regression"
        task_type = st.sidebar.radio("Task Type", ["Classification", "Regression"], index=0 if inferred_task=="Classification" else 1)
        print("CSV Task type:", task_type)
        
        model_choice = st.sidebar.selectbox("Select Model", ["Random Forest", "XGBoost (if installed)"])
        print("CSV Model selected:", model_choice)
        st.sidebar.subheader("Hyperparameters")
        n_estimators = st.sidebar.slider("n_estimators", 10, 500, 100, step=10)
        max_depth = st.sidebar.slider("max_depth", 1, 50, 5, step=1)
        params = {"n_estimators": n_estimators, "max_depth": max_depth}
        print("CSV Hyperparameters:", params)
        
        numeric_cols, categorical_cols = get_feature_types(df, target_col)
        preprocessor = create_preprocessing_pipeline(numeric_cols, categorical_cols)
        y_processed, target_encoder = preprocess_target(y)
        X = df.drop(columns=[target_col])
        X_train, X_test, y_train, y_test = train_test_split(X, y_processed, test_size=0.2, random_state=42)
        print("CSV Data split into train/test.")
        
        model = None
        if task_type == "Classification":
            if model_choice == "Random Forest":
                model = RandomForestClassifier(**params, random_state=42)
            elif model_choice.startswith("XGBoost"):
                try:
                    from xgboost import XGBClassifier
                    model = XGBClassifier(**params, use_label_encoder=False, eval_metric='mlogloss', random_state=42)
                except ImportError:
                    st.error("XGBoost not installed.")
        else:
            if model_choice == "Random Forest":
                model = RandomForestRegressor(**params, random_state=42)
            elif model_choice.startswith("XGBoost"):
                try:
                    from xgboost import XGBRegressor
                    model = XGBRegressor(**params, random_state=42)
                except ImportError:
                    st.error("XGBoost not installed.")
        
        if model is None:
            st.error("CSV Model initialization failed.")
            print("CSV Model init failed.")
        else:
            print("CSV Model initialized:", model)
        
        with tab_overview:
            st.header("CSV Dataset Overview")
            st.markdown("### Data Summary")
            st.dataframe(df.describe(include='all').T)
            st.markdown("### Column Overview")
            overview_data = {
                "Column": df.columns,
                "Data Type": [str(df[col].dtype) for col in df.columns],
                "Missing Values": [df[col].isnull().sum() for col in df.columns],
                "Unique Values": [df[col].nunique() for col in df.columns],
                "Sample Values": [', '.join(map(str, list(df[col].dropna().unique()[:3]))) for col in df.columns],
            }
            st.dataframe(pd.DataFrame(overview_data))
            print("CSV Overview displayed.")
        
        with tab_viz:
            st.header("CSV Data Visualizations")
            st.subheader("Distribution Plot")
            col_to_plot = st.selectbox("Select Column for Distribution", df.columns.tolist())
            try:
                fig_dist = px.histogram(df, x=col_to_plot, title=f"Distribution of {col_to_plot}")
                st.plotly_chart(fig_dist, use_container_width=True)
                print(f"CSV Distribution for {col_to_plot} displayed.")
            except Exception as e:
                st.error(f"Error in CSV distribution plot: {e}")
            if numeric_cols:
                st.subheader("Correlation Heatmap (Numeric Features)")
                corr = df[numeric_cols].corr()
                fig, ax = plt.subplots(figsize=(10,8))
                sns.heatmap(corr, annot=True, cmap="coolwarm", ax=ax)
                st.pyplot(fig)
                print("CSV Correlation heatmap displayed.")
            if st.checkbox("Show Pair Plot", value=False):
                try:
                    fig_pair = ff.create_scatterplotmatrix(df[numeric_cols], diag='histogram', index=0, height=800, width=800)
                    st.plotly_chart(fig_pair)
                    print("CSV Pair plot displayed.")
                except Exception as e:
                    st.error(f"CSV Pair plot error: {e}")
        
        with tab_model:
            st.header("CSV Model Training")
            if model is None:
                st.error("CSV Model init failed.")
            else:
                st.write("Training CSV pipeline with preprocessing...")
                pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('model', model)])
                pipeline.fit(X_train, y_train)
                st.success("CSV Model training complete!")
                st.session_state[csv_pipeline_key] = pipeline
                print("CSV Model trained and stored.")
        
        with tab_eval:
            st.header("CSV Model Evaluation")
            if csv_pipeline_key not in st.session_state:
                st.error("Please train the CSV model first.")
            else:
                pipeline = st.session_state[csv_pipeline_key]
                y_pred = pipeline.predict(X_test)
                if task_type == "Classification":
                    acc = accuracy_score(y_test, y_pred)
                    st.write(f"**Accuracy:** {acc:.4f}")
                    cm = confusion_matrix(y_test, y_pred)
                    class_names = target_encoder.classes_ if target_encoder is not None else np.unique(y_test)
                    st.pyplot(plot_confusion_matrix(cm, class_names))
                    st.dataframe(pd.DataFrame(classification_report(y_test, y_pred, output_dict=True)).transpose())
                    if len(np.unique(y_test)) == 2:
                        try:
                            y_proba = pipeline.predict_proba(X_test)
                            st.plotly_chart(plot_roc_curve(y_test, y_proba, pos_label=1))
                            print("CSV ROC curve displayed.")
                        except Exception as e:
                            st.error(f"CSV ROC error: {e}")
                else:
                    mse = mean_squared_error(y_test, y_pred)
                    r2 = r2_score(y_test, y_pred)
                    st.write(f"**MSE:** {mse:.4f}")
                    st.write(f"**R²:** {r2:.4f}")
                    st.plotly_chart(plot_residuals(y_test, y_pred))
                print("CSV Evaluation displayed.")
        
        with tab_custom:
            st.header("CSV Custom Model Integration")
            custom_model_file = st.file_uploader("Upload custom model (Pickle file)", type=["pkl"], key="custom_model_csv")
            if custom_model_file is not None:
                try:
                    custom_model = joblib.load(custom_model_file)
                    st.success("CSV Custom model loaded!")
                    print("CSV Custom model loaded.")
                    if st.button("Evaluate Custom Model"):
                        y_pred_custom = custom_model.predict(X_test)
                        if task_type == "Classification":
                            acc_custom = accuracy_score(y_test, y_pred_custom)
                            st.write(f"**Custom Model Accuracy:** {acc_custom:.4f}")
                            cm_custom = confusion_matrix(y_test, y_pred_custom)
                            class_names = target_encoder.classes_ if target_encoder is not None else np.unique(y_test)
                            st.pyplot(plot_confusion_matrix(cm_custom, class_names))
                            st.dataframe(pd.DataFrame(classification_report(y_test, y_pred_custom, output_dict=True)).transpose())
                        else:
                            mse_custom = mean_squared_error(y_test, y_pred_custom)
                            r2_custom = r2_score(y_test, y_pred_custom)
                            st.write(f"**Custom Model MSE:** {mse_custom:.4f}")
                            st.write(f"**Custom Model R²:** {r2_custom:.4f}")
                        print("CSV Custom model evaluation complete.")
                except Exception as e:
                    st.error(f"CSV Custom model load error: {e}")
                    print("CSV Custom model load error:", e)
        
        with tab_predict:
            st.header("CSV Predictions")
            input_data = {}
            for col in X.columns:
                if col in numeric_cols:
                    input_data[col] = st.number_input(f"{col}", value=float(X[col].mean()))
                else:
                    uv = df[col].dropna().unique().tolist()
                    if not uv:
                        uv = [""]
                    input_data[col] = st.selectbox(f"{col}", uv)
            input_df = pd.DataFrame([input_data])
            if st.button("Predict"):
                if csv_pipeline_key not in st.session_state:
                    st.error("No trained CSV model available. Train first.")
                    print("CSV Predict error: no model.")
                else:
                    pipeline = st.session_state[csv_pipeline_key]
                    try:
                        prediction = pipeline.predict(input_df)
                        if task_type == "Classification" and target_encoder is not None:
                            prediction = target_encoder.inverse_transform(prediction)
                        st.write("### Prediction:")
                        st.write(prediction)
                        print("CSV Prediction:", prediction)
                    except Exception as e:
                        st.error(f"CSV Prediction error: {e}")
                        print("CSV Prediction error:", e)
        
        st.sidebar.header("Download CSV Model")
        if csv_pipeline_key in st.session_state:
            try:
                model_bytes = pickle.dumps(st.session_state[csv_pipeline_key])
                st.sidebar.download_button("Download Model", data=model_bytes, file_name="trained_pipeline_csv.pkl")
                print("CSV Model download created.")
            except Exception as e:
                st.sidebar.error(f"CSV Download error: {e}")
                print("CSV Model download error:", e)
else:
    st.write("Upload a CSV file via the sidebar to begin.")
    print("No CSV file uploaded.")

###############################################
# SENSOR DATA PROCESSING SECTION
###############################################
with tab_sensor:
    st.header("Sensor Data Processing")
    st.write("Upload multiple sensor file pairs. For each pair, set parameters and a label. Then click 'Generate Combined Sensor Data', split the data (e.g., 80/20), and train a model (Decision Tree or Random Forest).")
    
    # Button to clear sensor data from session_state
    if st.button("Clear Sensor Data"):
        for key in ["sensor_data_list", "combined_sensor_data"]:
            if key in st.session_state:
                del st.session_state[key]
        st.success("Sensor data cleared.")
    
    # Multi-file upload for accelerometer and gyroscope files
    accel_files = st.file_uploader("Upload Accelerometer Files (.dat)", type=["dat"], accept_multiple_files=True, key="accel_files")
    gyro_files = st.file_uploader("Upload Gyroscope Files (.dat)", type=["dat"], accept_multiple_files=True, key="gyro_files")
    
    # Retrieve or initialize sensor data settings list
    sensor_data_list = st.session_state.get("sensor_data_list", [])
    
    if accel_files and gyro_files:
        num_pairs = min(len(accel_files), len(gyro_files))
        st.write(f"Found {num_pairs} file pair(s).")
        # For each file pair, let user set parameters in an expander
        for i in range(num_pairs):
            with st.expander(f"File Pair {i+1} Settings", expanded=True):
                st.write("File names:")
                st.write(f"Accelerometer: {accel_files[i].name}")
                st.write(f"Gyroscope: {gyro_files[i].name}")
                sampling_rate = st.number_input(f"Sampling Rate for Pair {i+1} (Hz)", value=100.0, step=1.0, key=f"sr_{i}")
                start_timestamp = st.number_input(f"Start Timestamp for Pair {i+1} (s)", value=0.0, step=0.1, key=f"ts_{i}")
                apply_kf = st.checkbox(f"Apply Kalman Filter for Pair {i+1}", value=True, key=f"kf_{i}")
                label_val = st.text_input(f"Label for Pair {i+1}", value="NORMAL", key=f"label_{i}")
                pair_settings = {
                    "accel_file": accel_files[i],
                    "gyro_file": gyro_files[i],
                    "sampling_rate": sampling_rate,
                    "start_timestamp": start_timestamp,
                    "apply_kf": apply_kf,
                    "label": label_val
                }
                if len(sensor_data_list) > i:
                    sensor_data_list[i] = pair_settings
                else:
                    sensor_data_list.append(pair_settings)
        st.session_state["sensor_data_list"] = sensor_data_list
        
        # Button to generate combined sensor data from all file pairs
        if st.button("Generate Combined Sensor Data"):
            combined_list = []
            for idx, pair in enumerate(sensor_data_list):
                accel_data = parse_lsm6dsv16x(pair["accel_file"], "accelerometer")
                gyro_data = parse_lsm6dsv16x(pair["gyro_file"], "gyroscope")
                if accel_data.size == 0 or gyro_data.size == 0:
                    st.error(f"Error parsing files for pair {idx+1}. Skipping this pair.")
                    continue
                num_samples = min(len(accel_data), len(gyro_data))
                accel_data = accel_data[:num_samples]
                gyro_data = gyro_data[:num_samples]
                timestamps = pair["start_timestamp"] + np.arange(num_samples) * (1.0 / pair["sampling_rate"])
                if pair["apply_kf"]:
                    accel_kf = np.zeros_like(accel_data, dtype=float)
                    for j in range(3):
                        accel_kf[:, j] = kalman_filter(accel_data[:, j])
                else:
                    accel_kf = np.full_like(accel_data, np.nan)
                use_data = accel_kf if pair["apply_kf"] else accel_data
                roll = np.degrees(np.arctan2(use_data[:, 1], use_data[:, 2]))
                pitch = np.degrees(np.arctan2(-use_data[:, 0], np.sqrt(use_data[:, 1]**2 + use_data[:, 2]**2)))
                dt = 1.0 / pair["sampling_rate"]
                yaw = np.cumsum(gyro_data[:, 2]) * dt
                df_pair = pd.DataFrame({
                    "Timestamp_s": timestamps,
                    "Sampling_Rate": pair["sampling_rate"],
                    "AccelX_Gs": accel_data[:, 0],
                    "AccelY_Gs": accel_data[:, 1],
                    "AccelZ_Gs": accel_data[:, 2],
                    "AccelX_KF_Gs": accel_kf[:, 0] if pair["apply_kf"] else np.nan,
                    "AccelY_KF_Gs": accel_kf[:, 1] if pair["apply_kf"] else np.nan,
                    "AccelZ_KF_Gs": accel_kf[:, 2] if pair["apply_kf"] else np.nan,
                    "Roll_deg": roll,
                    "Pitch_deg": pitch,
                    "Yaw_deg": yaw,
                    "Label": pair["label"]
                })
                combined_list.append(df_pair)
            if combined_list:
                combined_df = pd.concat(combined_list, ignore_index=True)
                st.subheader("Combined Sensor Data")
                st.dataframe(combined_df.head(10))
                st.session_state["combined_sensor_data"] = combined_df
                st.success("Combined sensor data generated.")
                print("Combined sensor data generated, shape:", combined_df.shape)
            else:
                st.error("No sensor data was processed.")
    
    else:
        st.info("Please upload both accelerometer and gyroscope .dat files.")
        print("Sensor files not uploaded yet.")
    
    # If combined sensor data exists, allow splitting and training models
    if "combined_sensor_data" in st.session_state:
        st.markdown("### Split & Train on Combined Sensor Data")
        combined_df = st.session_state["combined_sensor_data"]
        split_percent = st.slider("Train Split Percentage", min_value=50, max_value=90, value=80, step=5)
        train_ratio = split_percent / 100.0
        st.write(f"Train/Test Split: {int(train_ratio*100)}% / {int((1-train_ratio)*100)}%")
        if "Label" not in combined_df.columns:
            st.error("Combined sensor data does not contain a 'Label' column.")
        else:
            X_sensor = combined_df.drop(columns=["Label"])
            y_sensor = combined_df["Label"]
            X_train_s, X_test_s, y_train_s, y_test_s = train_test_split(X_sensor, y_sensor, test_size=(1-train_ratio), random_state=42)
            algo_choice = st.selectbox("Select Algorithm", ["Decision Tree", "Random Forest"], key="sensor_algo")
            if algo_choice == "Decision Tree":
                sensor_model = DecisionTreeClassifier(random_state=42)
            else:
                sensor_model = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
            if st.button("Train Sensor Model"):
                sensor_model.fit(X_train_s, y_train_s)
                y_pred_s = sensor_model.predict(X_test_s)
                acc_sensor = accuracy_score(y_test_s, y_pred_s)
                st.write(f"**Sensor Model Accuracy:** {acc_sensor:.4f}")
                st.write("### Confusion Matrix")
                cm_sensor = confusion_matrix(y_test_s, y_pred_s)
                class_names = np.unique(y_sensor)
                st.pyplot(plot_confusion_matrix(cm_sensor, class_names))
                st.success("Sensor model training complete.")
                st.session_state["sensor_model"] = sensor_model
                print("Sensor model trained. Accuracy:", acc_sensor)
                # Download sensor model as pickle
                sensor_model_pickle = pickle.dumps(sensor_model)
                st.download_button("Download Sensor Model (Pickle)", data=sensor_model_pickle, file_name="sensor_model.pkl")
                # Download combined sensor data as CSV
                sensor_csv_bytes = combined_df.to_csv(index=False).encode('utf-8')
                st.download_button("Download Combined Sensor Data (CSV)", data=sensor_csv_bytes, file_name="combined_sensor_data.csv")
                print("Sensor model and data download buttons created.")
